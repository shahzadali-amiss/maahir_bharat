<!-- Become Courier / Partner CTA-->
      <section class="container mt-5 pt-md-4">
        <div class="row">
          <!-- <div class="col-lg-6 mb-grid-gutter">
            <div class="d-block d-sm-flex justify-content-between align-items-center bg-faded-info rounded-3">
              <div class="pt-5 py-sm-5 px-4 ps-md-5 pe-md-0 text-center text-sm-start">
                <h2>Become a Courier</h2>
                <p class="text-muted pb-2">Earn competitive salary as delivery courier working flexible schedule.</p><a class="btn btn-primary" href="#">Start earning</a>
              </div><img class="d-block mx-auto mx-sm-0" src="img/food-delivery/courier.png" width="272" alt="Become a Courier">
            </div>
          </div> -->
          <div class="col-lg-12">
            <div class="d-block d-sm-flex justify-content-between align-items-center bg-faded-warning rounded-3 px-md-5">
              <div class="pt-5 py-sm-5 px-4 ps-md-5 pe-md-0 text-center text-sm-start">
                <h2>Become a Supplier</h2>
                <p class="text-muted pb-2">Grow your business by reaching new customers.</p><a class="btn btn-primary" href="{{ route('become-a-supplier') }}">Be a Supplier</a>
              </div>
              <img class="d-block mx-auto mx-sm-0" src="img/food-delivery/chef.png" width="269" alt="Become a Partner">
            </div>
          </div>
        </div>
      </section>