<!-- Toolbar for handheld devices (Default)-->
    <div class="handheld-toolbar">
      <div class="d-table table-layout-fixed w-100">
        <a class="d-table-cell handheld-toolbar-item" href="account-wishlist.html">
          <span class="handheld-toolbar-icon">
            <i class="ci-heart"></i>
          </span>
          <span class="handheld-toolbar-label">Wishlist</span>
        </a>
        <a class="d-table-cell handheld-toolbar-item" href="javascript:void(0)" data-bs-toggle="collapse" data-bs-target="#navbarCollapse" onclick="window.scrollTo(0, 0)">
          <span class="handheld-toolbar-icon">
            <i class="ci-menu"></i>
          </span>
          <span class="handheld-toolbar-label">Menu</span>
        </a>
        <a class="d-table-cell handheld-toolbar-item" href="shop-cart.html">
          <span class="handheld-toolbar-icon">
            <i class="ci-cart"></i>
            <span class="badge bg-primary rounded-pill ms-1">4</span>
          </span>
          <span class="handheld-toolbar-label">₹265.00</span>
        </a>
      </div>
    </div>