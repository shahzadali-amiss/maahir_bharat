<!-- Topbar-->
        <div class="topbar topbar-dark bg-dark d-none d-md-block">
          <div class="container">
            <div>
              <div class="topbar-text text-nowrap d-none d-md-inline-block ps-3 ms-3"><span class="text-white me-1">Available 24/7 at</span><a class="topbar-link text-white" href="tel:9927686940">(91) 99276 86940</a></div>
            </div>
            <div class="topbar-text dropdown d-md-none ms-auto"><a class="dropdown-item text-white" href=""><i class="ci-location me-2"></i>Order tracking</a>
            </div>
            <div class="d-md-block ms-3 text-nowrap"><a class="topbar-link ms-3  ps-3 d-none d-md-inline-block text-white" href="#"><i class="ci-location mt-n1"></i>Order tracking</a></div>
          </div>
        </div>