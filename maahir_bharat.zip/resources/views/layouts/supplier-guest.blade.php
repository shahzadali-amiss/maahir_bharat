@include('inc.seller-header')
@yield('content')
@include('inc.seller-footer')
