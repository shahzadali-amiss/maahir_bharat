@include('admin.inc.header')

@include('admin.inc.top-nav')


@include('admin.inc.sidebar')
<div class="main-panel pt-5">

@yield('content')

@include('admin.inc.footer')

