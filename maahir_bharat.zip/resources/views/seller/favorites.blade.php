@extends('layouts.seller')
@section('content')

<!-- Content-->
<section class="col-lg-8 pt-lg-4 pb-4 mb-3">
  <div class="pt-2 px-4 ps-lg-0 pe-xl-5">
    <h2 class="h3 pt-2 pb-4 mb-0 text-center text-sm-start border-bottom">Favorites<span class="badge bg-faded-accent fs-sm text-body align-middle ms-2">4</span></h2>
    <!-- Product-->
    <div class="d-block d-sm-flex align-items-center py-4 border-bottom"><a class="d-block position-relative mb-3 mb-sm-0 me-sm-4 ms-sm-0 mx-auto" href="marketplace-single.html" style="width: 12.5rem;"><img class="rounded-3" src="../img/marketplace/products/th02.jpg" alt="Product"><span class="btn btn-icon btn-danger position-absolute top-0 end-0 py-0 px-1 m-2" data-bs-toggle="tooltip" title="Remove from Favorites"><i class="ci-trash"></i></span></a>
      <div class="text-center text-sm-start">
        <h3 class="h6 product-title mb-2"><a href="marketplace-single.html">UI Isometric Devices Pack (PSD)</a></h3>
        <div class="d-inline-block text-accent">$23.<small>00</small></div><a class="d-inline-block text-accent fs-ms border-start ms-2 ps-2" href="marketplace-vendor.html">by uidesigner</a>
        <div class="d-sm-flex align-items-center pt-2">
          <select class="form-select form-select-sm my-1 me-2">
            <option>Standard license</option>
            <option>Extended license</option>
          </select>
          <button class="btn btn-primary btn-sm mx-auto mx-sm-0 my-2" type="button"><i class="ci-cart me-1"></i>Add to Cart</button>
        </div>
      </div>
    </div>
    <!-- Product-->
    <div class="d-block d-sm-flex align-items-center py-4 border-bottom"><a class="d-block position-relative mb-3 mb-sm-0 me-sm-4 ms-sm-0 mx-auto" href="marketplace-single.html" style="width: 12.5rem;"><img class="rounded-3" src="../img/marketplace/products/th06.jpg" alt="Product"><span class="btn btn-icon btn-danger position-absolute top-0 end-0 py-0 px-1 m-2" data-bs-toggle="tooltip" title="Remove from Favorites"><i class="ci-trash"></i></span></a>
      <div class="text-center text-sm-start">
        <h3 class="h6 product-title mb-2"><a href="marketplace-single.html">Project Devices Showcase (PSD)</a></h3>
        <div class="d-inline-block text-accent">$18.<small>00</small></div><a class="d-inline-block text-accent fs-ms border-start ms-2 ps-2" href="marketplace-vendor.html">by pixels</a>
        <div class="d-sm-flex align-items-center pt-2">
          <select class="form-select form-select-sm my-1 me-2">
            <option>Standard license</option>
            <option>Extended license</option>
          </select>
          <button class="btn btn-primary btn-sm mx-auto mx-sm-0 my-2" type="button"><i class="ci-cart me-1"></i>Add to Cart</button>
        </div>
      </div>
    </div>
    <!-- Product-->
    <div class="d-block d-sm-flex align-items-center py-4 border-bottom"><a class="d-block position-relative mb-3 mb-sm-0 me-sm-4 ms-sm-0 mx-auto" href="marketplace-single.html" style="width: 12.5rem;"><img class="rounded-3" src="../img/marketplace/products/th01.jpg" alt="Product"><span class="btn btn-icon btn-danger position-absolute top-0 end-0 py-0 px-1 m-2" data-bs-toggle="tooltip" title="Remove from Favorites"><i class="ci-trash"></i></span></a>
      <div class="text-center text-sm-start">
        <h3 class="h6 product-title mb-2"><a href="marketplace-single.html">Top View Smartwatch 3D Render</a></h3>
        <div class="d-inline-block text-accent">$19.<small>00</small></div><a class="d-inline-block text-accent fs-ms border-start ms-2 ps-2" href="marketplace-vendor.html">by modello</a>
        <div class="d-sm-flex align-items-center pt-2">
          <select class="form-select form-select-sm my-1 me-2">
            <option>Standard license</option>
            <option>Extended license</option>
          </select>
          <button class="btn btn-primary btn-sm mx-auto mx-sm-0 my-2" type="button"><i class="ci-cart me-1"></i>Add to Cart</button>
        </div>
      </div>
    </div>
    <!-- Product-->
    <div class="d-block d-sm-flex align-items-center pt-4 pb-2"><a class="d-block position-relative mb-3 mb-sm-0 me-sm-4 ms-sm-0 mx-auto" href="marketplace-single.html" style="width: 12.5rem;"><img class="rounded-3" src="../img/marketplace/products/th07.jpg" alt="Product"><span class="btn btn-icon btn-danger position-absolute top-0 end-0 py-0 px-1 m-2" data-bs-toggle="tooltip" title="Remove from Favorites"><i class="ci-trash"></i></span></a>
      <div class="text-center text-sm-start">
        <h3 class="h6 product-title mb-2"><a href="marketplace-single.html">Gravity Devices UI Mockup (PSD)</a></h3>
        <div class="d-inline-block text-accent">$15.<small>00</small></div><a class="d-inline-block text-accent fs-ms border-start ms-2 ps-2" href="marketplace-vendor.html">by pixels</a>
        <div class="d-sm-flex align-items-center pt-2">
          <select class="form-select form-select-sm my-1 me-2">
            <option>Standard license</option>
            <option>Extended license</option>
          </select>
          <button class="btn btn-primary btn-sm mx-auto mx-sm-0 my-2" type="button"><i class="ci-cart me-1"></i>Add to Cart</button>
        </div>
      </div>
    </div>
  </div>
</section>

@endsection