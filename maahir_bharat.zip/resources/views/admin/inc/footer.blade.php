        <footer class="footer">
          <div class="d-sm-flex justify-content-center justify-content-sm-between">
            <span class="text-muted text-center text-sm-left d-block d-sm-inline-block">Copyright © 2021. <a href="#" target="_blank">MaahirBharat</a> . All rights reserved.</span>
            <span class="float-none float-sm-right d-block mt-1 mt-sm-0 text-center">Hand-crafted & made with <i class="ti-heart text-danger ms-1"></i></span>
          </div>
        </footer>
        <!-- partial -->
      </div>
      <!-- main-panel ends -->
    </div>
    <!-- page-body-wrapper ends -->
  </div>
  <!-- container-scroller -->

  <!-- plugins:js -->
  <script src="{{asset('admin_assets/js/jquery.min.js')}}"></script>
  <script src="https://maxcdn.bootstrapcdn.com/bootstrap/4.0.0/js/bootstrap.min.js" integrity="sha384-JZR6Spejh4U02d8jOt6vLEHfe/JQGiRRSQQxSfFWpi1MquVdAyjUar5+76PVCmYl" crossorigin="anonymous"></script>

  <script src="{{asset('admin_assets/vendors/js/vendor.bundle.base.js')}}"></script>
  <!-- endinject -->
  <!-- Plugin js for this page -->
  <script src="{{asset('admin_assets/vendors/chart.js/Chart.min.js')}}"></script>
  <script src="{{asset('admin_assets/vendors/datatables.net/jquery.dataTables.js')}}"></script>
  <script src="{{asset('admin_assets/vendors/datatables.net-bs4/dataTables.bootstrap4.js')}}"></script>
  <script src="{{asset('admin_assets/vendors/jquery-file-upload/jquery.uploadfile.min.js')}}"></script>
  <script src="{{asset('admin_assets/js/dataTables.select.min.js')}}"></script>

  <!-- End plugin js for this page -->
  <!-- inject:js -->
  <script src="{{asset('admin_assets/js/off-canvas.js')}}"></script>
  <script src="https://kit.fontawesome.com/3d8c19b62e.js" crossorigin="anonymous"></script>
  <script src="{{asset('admin_assets/js/hoverable-collapse.js')}}"></script>
  <script src="{{asset('admin_assets/js/template.js')}}"></script>
  <script src="{{asset('admin_assets/js/settings.js')}}"></script>
  <script src="{{asset('admin_assets/js/todolist.js')}}"></script>
  <!-- endinject -->
  <!-- Custom js for this page-->
  <script src="{{asset('admin_assets/js/jquery.cookie.js')}}" type="text/javascript"></script>
  <script src="{{asset('admin_assets/js/jquery-file-upload.js')}}"></script>
  <script src="{{asset('admin_assets/js/dashboard.js')}}"></script>
  <script src="{{asset('admin_assets/js/Chart.roundedBarCharts.js')}}"></script>
  <script src="{{asset('admin_assets/js/data-table.js')}}"></script>
  <script src="{{asset('select2/js/select2.full.js')}}"></script>
  <script src="{{asset('admin_assets/js/mycustom.js')}}"></script>
  @stack('scripts')
  <!-- <script src="https://cdn.jsdelivr.net/npm/select2@4.1.0-rc.0/dist/js/select2.min.js"></script> -->
  <!-- End custom js for this page-->
</body>
</html>

