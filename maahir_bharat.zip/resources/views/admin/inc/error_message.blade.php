

@error($name)
  <span class="text-danger msg_size">{{$message}}</span>
@enderror