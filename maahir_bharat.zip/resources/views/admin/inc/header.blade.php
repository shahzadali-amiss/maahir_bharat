<!DOCTYPE html>
<html lang="en">
<head> 
  <!-- Required meta tags -->
  <meta charset="utf-8">
  <meta name="viewport" content="width=device-width, initial-scale=1, shrink-to-fit=no">
  <title>MAHIR BHARAT-Admin</title>
  <!-- plugins:css -->
  <link rel="stylesheet" href="{{asset('admin_assets/vendors/feather/feather.css')}}">
  <link rel="stylesheet" href="{{asset('admin_assets/vendors/ti-icons/css/themify-icons.css')}}">
  <link rel="stylesheet" href="{{asset('admin_assets/vendors/css/vendor.bundle.base.css')}}">
  <!-- endinject -->
  <!-- Plugin css for this page -->
  <link rel="stylesheet" href="{{asset('admin_assets/vendors/datatables.net-bs4/dataTables.bootstrap4.css')}}">
  <link rel="stylesheet" href="{{asset('admin_assets/vendors/ti-icons/css/themify-icons.css')}}">
  <link rel="stylesheet" href="{{asset('admin_assets/vendors/simple-line-icons/css/simple-line-icons.css')}}">
  <link rel="stylesheet" href="{{asset('admin_assets/vendors/jquery-file-upload/uploadfile.css')}}">
  <link rel="stylesheet" type="text/css" href="{{asset('admin_assets/js/select.dataTables.min.css')}}">
  <!-- End plugin css for this page -->
  <!-- inject:css -->
  <link rel="stylesheet" href="{{asset('admin_assets/css/vertical-layout-light/style.css')}}">
  <link rel="stylesheet" href="{{asset('select2/css/select2.css')}}">
  <link rel="stylesheet" href="{{asset('admin_assets/css/style.css')}}">
  @stack('styles')
  <!-- endinject -->
  <link rel="shortcut icon" href="{{asset('img/logo-dark.png')}}"/>
<!--   <link href="https://cdn.jsdelivr.net/npm/select2@4.1.0-rc.0/dist/css/select2.min.css" rel="stylesheet" /> -->

</head>
<body>
  <div class="container-scroller">
    
